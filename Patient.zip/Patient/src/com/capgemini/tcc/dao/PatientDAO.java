package com.capgemini.tcc.dao;
 
import com.capgemini.tcc.bean.*;
import com.capgemini.tcc.service.PatientService;
 
import java.sql.*;
interface IPatientDAO{  //INTERFACE
 
	int addPatientDetails(PatientBean patient);
	PatientBean getPatientDetails(int patientId);
 
}
 
public class PatientDAO implements IPatientDAO{  
 
 
	public int addPatientDetails(PatientBean patient)  //SWITCH CASE OPTION 1 METHOD DEFINITION AND LOGIC
	{
		int id=0;
		try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg634","training634");
		String sql;
		PatientService obj=new PatientService();
		obj.addPatientDetails(patient);
		sql="INSERT INTO PATIENT(patient_id,patient_name,age,pno,pdesc) VALUES (patient_id.NEXTVAL,'"+patient.getPname()+"',"+patient.getAge()+","+patient.getPno()+",'"+patient.getPdesc()+"')";
		Statement stmt=c.createStatement();
		stmt.executeQuery(sql);
		String sql1="select patient_id from patient where patient_name='"+patient.getPname()+"'";
		ResultSet rs=stmt.executeQuery(sql1);
		while(rs.next())
		{
			id=(rs.getInt(1));
		}
		stmt.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return id;
 
 
 
	}
 
	public PatientBean getPatientDetails(int patientId)	//SWITCH CASE OPTION 2 METHOD DEFINITION AND LOGIC
	{
		try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg634","training634");
		String sql="select * from patient where patient_id="+patientId;
		Statement stmt=c.createStatement();
		int i=stmt.executeUpdate(sql);
		if(i==0)
		{
			System.out.println("There is no patient with this ID");
		}
		else {
	    ResultSet rs=stmt.executeQuery(sql);
		while(rs.next())
		{
			System.out.println("Name of the Patient : "+rs.getString(2)+"\n"+"Age : "+rs.getInt(3)+"\n"+"Phone Number  : "+rs.getString(4)+"\n"+"Description : "+rs.getString(5)+"\n"+"Consultation Date : "+rs.getDate(6));
		}
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		PatientBean obj=null;
		return obj;
	}
}